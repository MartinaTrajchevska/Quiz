# Quiz
This project is going to be a quiz for beginners in programming to decide easily what they want to learn.  There will be questions about what are they interested in, what kind of previous experience they have etc. and according to that, it will give them directions what will be the best for them to learn and what resources to use.
